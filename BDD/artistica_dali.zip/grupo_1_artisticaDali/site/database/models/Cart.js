module.exports = (sequelize, dataTypes) =>{

    let alias = 'Cart';

    let cols = {
        id:{
            type: dataTypes.INTEGER(11),
            primaryKey: true,
            autoIncrement: true,
            allowNull: false    
        },
        usuario_id:{
            type: dataTypes.INTEGER(11),
            allowNull:false
        }
    }
    let config = {
        tableName: 'cart'
    }

    const Cart = sequelize.define(alias, cols, config);

    return Cart

}
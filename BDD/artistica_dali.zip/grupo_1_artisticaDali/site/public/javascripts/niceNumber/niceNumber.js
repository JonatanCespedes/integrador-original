$(function(){
    $('.number-spinner').niceNumber();
});